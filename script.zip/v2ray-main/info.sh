#!/bin/bash

clear
neofetch