## Installation

`wget https://raw.githubusercontent.com/natxanss/v2ray/main/setup.sh && chmod +x setup.sh && ./setup.sh && rm setup.sh`
